function [matriz_resultados] = FCTS(c,d,L,T,deltat,deltax)



    % definindo repartições d malha
    tamanho_malha_x = floor(L/deltax+1);
    tamanho_malha_t = floor(T/deltat+1);
    


    %//definindo matriz de convolução
    matriz_conv = zeros(tamanho_malha_x,tamanho_malha_x);
    entrada_diagonal_principal = d-(2*c)/deltax^2 + 1/deltat;
    entrada_diagonais = c/deltax^2;
    for i=1:tamanho_malha_x-1
        matriz_conv(i,i) = entrada_diagonal_principal;
        matriz_conv(i+1,i) = entrada_diagonais;
        matriz_conv(i,i+1) = entrada_diagonais;
    end
    matriz_conv(tamanho_malha_x,tamanho_malha_x)=entrada_diagonal_principal;
    matriz_conv = deltat*matriz_conv;
    %disp(matriz_conv);

    %//definindo u no tempo 0 
    x=0;
    for i=1:tamanho_malha_x
       U_i_j(i,1) = sin((pi*x)/2)^2;
       %//disp('sin:',sin((pi*x)/2));
       x = x + deltax;
    end
    matriz_resultados(1,:) = U_i_j';
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %passo iterativo
    for i=2:tamanho_malha_t
        %disp(matriz_conv*U_i_j);
        U_i_jplus = matriz_conv*U_i_j;
        U_i_jplus(1,1) = 0;
        %disp(tamanho_malha_t)
        %disp(tamanho_malha_x)
        U_i_jplus(tamanho_malha_x,1) = 0;
        %disp(U_i_jplus);
        matriz_resultados(i,:) = U_i_jplus';
        U_i_j=U_i_jplus;
    end

    %disp(matriz_resultados);
    %//plotando imagem
    x_vetor = linspace(0,L,(L/deltax)+1);
    t_vetor = linspace(0,T,(T/deltat)+1);
    %disp(x_vetor);
    X = zeros(size(matriz_resultados,1),size(matriz_resultados,2));
    T = zeros(size(matriz_resultados,1),size(matriz_resultados,2));
    for i=1:size(matriz_resultados,1)
        T(i,:) = t_vetor(1,i);
    end
    %disp('matriz resultado');
    %disp(matriz_resultados);
    for i=1:size(matriz_resultados,2)
        X(:,i) = x_vetor(1,i);
    end
    disp(matriz_conv);
    disp(matriz_resultados);
    %disp(matriz_resultados);
    %disp(X);
    %disp(T);
    %disp(matriz_resultados);
    surf(X,T,matriz_resultados, matriz_resultados, "EdgeColor","none");
    xlabel('X');
    ylabel('T');
    zlabel('U');
    colorbar;
end